package J07010_DanhSachSinhVien;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws FileNotFoundException {
        Scanner in = new Scanner(new File("SV.in"));
        int k = Integer.parseInt(in.nextLine());
        while (k-- > 0) {
            SinhVien sinhVien = new SinhVien(in.nextLine().trim(), in.nextLine().trim(), in.nextLine().trim(), Double.parseDouble(in.nextLine().trim()));
            System.out.println(sinhVien);
        }
    }
}
