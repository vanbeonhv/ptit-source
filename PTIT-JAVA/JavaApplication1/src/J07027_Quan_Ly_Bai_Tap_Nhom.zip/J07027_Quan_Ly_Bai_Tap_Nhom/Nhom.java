/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package J07027_Quan_Ly_Bai_Tap_Nhom;

/**
 *
 * @author nguye
 */
public class Nhom {

    private String msv;
    private int stt;

    public Nhom(String msv, int stt) {
        this.msv = msv;
        this.stt = stt;
    }

    public String getMsv() {
        return msv;
    }

    public int getStt() {
        return stt;
    }

}
